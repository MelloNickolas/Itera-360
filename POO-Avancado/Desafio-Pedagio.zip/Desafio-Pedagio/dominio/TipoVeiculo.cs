public enum TipoVeiculo
{
  Moto = 1,
  Carro = 2,
  Caminhao = 3
}
