public interface IPedagio
{
  public bool PassarPedagio(Veiculo veiculo);
  public bool VerificarCancela(Tag tag);
}