using Projeto360.Dominio.Entidades;

namespace Projeto360.Application;

public interface ITarefaAplicacao
{
  List<Tarefa> ListarTarefas();
}