namespace Projeto360.Dominio.Enumeradores;

public enum TipoUsuario
{
  Administrador = 1,
  Coordenador = 2,
  Cliente = 3
}