﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Projeto360.Repositories.Migrations
{
    public partial class Update2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
