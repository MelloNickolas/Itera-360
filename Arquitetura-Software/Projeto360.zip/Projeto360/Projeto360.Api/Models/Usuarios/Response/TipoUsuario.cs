namespace Projeto360.Api.Models.Response
{
  public class TipoUsuarioResponse
  {
    public int Id { get; set; }
    public string Nome { get; set; } = string.Empty;
  }
}
