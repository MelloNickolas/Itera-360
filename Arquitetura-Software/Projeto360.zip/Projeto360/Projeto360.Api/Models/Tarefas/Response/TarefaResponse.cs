namespace Projeto360.Api.Models.Tarefas.Response;

public class TarefaResponse
{
  public int ID { get; set; }
  public string Nome { get; set; }
  public bool Completa { get; set; }
}