﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LocadoraDesafio.Migrations
{
    public partial class JogoFinished : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
